<?php
$koneksi = new mysqli("localhost", "root", "", "sipangkat");
?>

<!-- end -->