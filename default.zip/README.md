# SI_Penjalu
Sistem Informasi Pengaduan Penerangan Jalan Umum

Database ada di Folder inc
